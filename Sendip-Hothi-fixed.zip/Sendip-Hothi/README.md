# 🎸 Chordstream

A hands-free guitar songbook with AI-powered chord lookup, auto-scrolling, key transposition, and precise chord placement above lyrics.

## Quick Start (Local)

**Prerequisites:** Node.js 18+

### 1. Install dependencies
```bash
npm install
```

### 2. Set up your API key
Copy `.env.local` and add your free Gemini API key:
```bash
# Edit .env.local and set:
GEMINI_API_KEY=your_key_here
```
Get a free key at: https://aistudio.google.com/apikey

### 3. Run the app
```bash
npm run dev
```
Open http://localhost:3000 — that's it! 🎸

---

## Deploy to Vercel (Free)

1. Push this repo to GitHub
2. Go to https://vercel.com → Import Project
3. Add environment variable: `GEMINI_API_KEY=your_key`
4. Click Deploy

Your app will be live at `yourapp.vercel.app` for free.

---

## Optional: Stripe Payments

To enable subscriptions, add these to your `.env.local`:
```
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
VITE_STRIPE_PUBLISHABLE_KEY=pk_live_...
VITE_STRIPE_MONTHLY_PRICE_ID=price_...
VITE_STRIPE_YEARLY_PRICE_ID=price_...
VITE_STRIPE_LIFETIME_PRICE_ID=price_...
```
The app runs fine without these — payments will just be disabled.

---

## Optional: Android App

```bash
npm run build
npm run android:sync
npm run android:open
```
Then build the APK from Android Studio.
